
package Logica;

import Modelos.*;
import java.util.ArrayList;
import java.util.List;


public class EjercicioOnReady {

   
    public static void main(String[] args) {
        
        Auto auto1 = new Auto("Peugeot", "206", 200000, 4);
        Moto moto1 = new Moto("Honda", "Titan", 60000, "125cc");
        Auto auto2 = new Auto("Peugeot", "208", 250000, 5);
        Moto moto2 = new Moto("Yamaha", "YBR", 80500.50, "160cc");
        
        Concesionaria concesionaria = new Concesionaria();
        
        concesionaria.agregarVehiculo(auto1);
        concesionaria.agregarVehiculo(moto1);
        concesionaria.agregarVehiculo(auto2);
        concesionaria.agregarVehiculo(moto2);
        
        concesionaria.mostrarDetalles();
        
        System.out.println("================================================");
        
        concesionaria.vehiculoCaro();
        concesionaria.vehiculoBarato();
        concesionaria.contieneY();
        
        System.out.println("================================================");
        
        concesionaria.ordenarVehiculos();
    }
    
}
