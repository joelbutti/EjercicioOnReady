/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.util.Comparator;

/**
 *
 * @author Joel
 */
public class CompararVehiculo implements Comparator <Concesionaria>{

    @Override
    public int compare(Concesionaria o1, Concesionaria o2) {

        double precio1= 0;
        double precio2=0;
        
        try {
            
            Auto auto1 = (Auto) o1;
            precio1 = auto1.getPrecio();
        } catch (Exception e) {
            
            Moto moto1 = (Moto) o1;
            precio1 = moto1.getPrecio();
            
        }
        
        try {
            
            Auto auto2 = (Auto) o2;
            precio2 = auto2.getPrecio();
        } catch (Exception e) {
            
            Moto moto2 = (Moto) o2;
            precio2= moto2.getPrecio();
        }
        
        if(precio1>precio2){
            
            return -1;
        }else if(precio1==precio2){
            
            return 0;
        }else{
            
            return 1;
        }
        
    }
    
}
