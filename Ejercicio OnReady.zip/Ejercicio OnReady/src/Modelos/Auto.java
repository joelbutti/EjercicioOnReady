/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Joel
 */
public class Auto extends Concesionaria {
    
    private String marca;
    private String modelo;
    private double precio;
    private int cantPuertas;

    public Auto() {
    }

    
    public Auto(String marca, String modelo, double precio, int cantPuertas) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.cantPuertas = cantPuertas;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantPuertas() {
        return cantPuertas;
    }

    public void setCantPuertas(int cantPuertas) {
        this.cantPuertas = cantPuertas;
    }
    
    

    
    
    
    
}
