/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Joel
 */
public class Concesionaria {
    
    private List<Concesionaria>listaVehiculos = new ArrayList();

    public List<Concesionaria> getListaVehiculos() {
        return listaVehiculos;
    }

    public void setListaVehiculos(List<Concesionaria> listaVehiculos) {
        this.listaVehiculos = listaVehiculos;
    }

    
    public void agregarVehiculo(Concesionaria vehi){
        
        
        this.listaVehiculos.add(vehi);
    }
    
    public void mostrarDetalles(){
    
        for(Concesionaria vehi : this.listaVehiculos){
            
            try {
                
                Auto auto = (Auto) vehi;
                System.out.println("Marca: " + auto.getMarca() + " // Modelo: " + auto.getModelo() + " // Puertas: "+ auto.getCantPuertas()+ " // Precio: " + auto.getPrecio());
                
            } catch (Exception e) {
                
                Moto moto = (Moto) vehi;
                System.out.println("Marca: " + moto.getMarca() + " // Modelo: " + moto.getModelo() + " // Cilindrada: "+ moto.getCilindrada()+ " // Precio: " + moto.getPrecio());

            }
        }
            
    }
    
    public void vehiculoCaro(){
        
        double precio = 0 ;
        Concesionaria vehiculo = new Concesionaria();
        
        for(Concesionaria vehi : listaVehiculos){
            
            try {
                
               Auto auto = (Auto) vehi; 
               
               if(auto.getPrecio()> precio){
                   
                   precio = auto.getPrecio();
                   vehiculo = (Concesionaria) auto;
               }
            } catch (Exception e) {
                
               Moto moto = (Moto) vehi; 
               
               if(moto.getPrecio()> precio){
                   
                   precio = moto.getPrecio();
                   vehiculo = (Concesionaria) moto;
               }
            }
        }
        
        try {
           
            Auto auto = (Auto) vehiculo;
            System.out.println("Vehiculo mas caro: " + auto.getMarca()+ " " + auto.getModelo());
        } catch (Exception e) {
            
            Moto moto = (Moto) vehiculo;
            System.out.println("Vehiculo mas caro: " + moto.getMarca()+ " " + moto.getModelo());
        }
    }
    
    public void vehiculoBarato(){
        
        double precio = 999999999 ;
        Concesionaria vehiculo = new Concesionaria();
        
        for(Concesionaria vehi : listaVehiculos){
            
            try {
                
               Auto auto = (Auto) vehi; 
               
               if(auto.getPrecio()< precio){
                   
                   precio = auto.getPrecio();
                   vehiculo = (Concesionaria) auto;
               }
            } catch (Exception e) {
                
               Moto moto = (Moto) vehi; 
               
               if(moto.getPrecio()< precio){
                   
                   precio = moto.getPrecio();
                   vehiculo = (Concesionaria) moto;
               }
            }
        }
        
        try {
           
            Auto auto = (Auto) vehiculo;
            System.out.println("Vehiculo mas barato: " + auto.getMarca()+ " " + auto.getModelo());
        } catch (Exception e) {
            
            Moto moto = (Moto) vehiculo;
            System.out.println("Vehiculo mas barato: " + moto.getMarca()+ " " + moto.getModelo());
        }
    }
    
    public void contieneY(){
        
        for(Concesionaria vehi : listaVehiculos){
            
            try {
                    
                Auto auto = (Auto) vehi; 
                
                if(auto.getModelo().toLowerCase().contains("y")){
                    
                    System.out.println("Vehiculo que contiene en el modelo la letra 'Y': "+ auto.getMarca() + " "+ auto.getModelo()+ " "+ auto.getPrecio());
                }
            } catch (Exception e) {
                
                Moto moto = (Moto) vehi; 
                
                if(moto.getModelo().toLowerCase().contains("y")){
                    
                    System.out.println("Vehiculo que contiene en el modelo la letra 'Y': "+ moto.getMarca() + " "+ moto.getModelo()+ " "+ moto.getPrecio());
                }
            }
        }
    }
    
    public void ordenarVehiculos(){
        
        Collections.sort(listaVehiculos, new CompararVehiculo());
        
        System.out.println("Vehiculos ordenados por precio de mayor a menor: ");
        for(Concesionaria vehi : listaVehiculos){
            
            try {
                
                Auto auto = (Auto) vehi;
                System.out.println(auto.getMarca()+" "+auto.getModelo());
                
            } catch (Exception e) {
                
                Moto moto = (Moto) vehi;
                System.out.println(moto.getMarca()+" "+moto.getModelo());

            }
        }
    }

    
}
